/* HUD Widget System - Core Functionality */
window.hudWidgets = window.hudWidgets || {};
window.hudWidgets.active = window.hudWidgets.active || {};

(function() {
  const hudContainer = document.getElementById('hudContainer');
  if (!hudContainer) return;
  function getDefaultPositions() {
    const W = window.innerWidth || 1920;
    const H = window.innerHeight || 1080;
    return {
      'ghost': { x: 437, y: 1008, w: 289, h: 112 },
      'ejection': { x: 13,  y: 915,  w: 410, h: 313 },
      'phase': { x: 17,  y: 614,  w: 290, h: 294 },
      'window': { x: 465, y: 1130, w: 330, h: 127 },
      'time': { x: 801, y: 1133, w: 326, h: 129 },
      'vessel': { x: 1657, y: 157, w: 345, h: 258 }
    };
  }

  window.hudWidgets.positions = getDefaultPositions();

  // Load from localStorage
  function loadPositions() {
    try {
      const saved = localStorage.getItem('kerbalist_widget_positions');
      if (saved) {
        const parsed = JSON.parse(saved);
        for (let k in parsed) {
          if (parsed[k] && parsed[k].w && parsed[k].w < 280) parsed[k].w = 290;
        }
        window.hudWidgets.positions = { ...window.hudWidgets.positions, ...parsed };
      }
    } catch (e) {}
  }

  // Save to localStorage
  function savePositions() {
    try {
      localStorage.setItem('kerbalist_widget_positions', JSON.stringify(window.hudWidgets.positions));
      const pinned = [];
      for (let [type, wid] of Object.entries(window.hudWidgets.active)) {
        const el = document.getElementById(wid);
        if (el && el.classList.contains('pinned')) pinned.push(type);
      }
      localStorage.setItem('kerbalist_widget_pinned', JSON.stringify(pinned));
    } catch (e) {}
  }

  loadPositions();

  // Puts every HUD element back at its default position and size, and clears the saved layout.
  window.resetHudLayout = function() {
    window.hudWidgets.positions = getDefaultPositions();
    try { localStorage.removeItem('kerbalist_widget_positions'); } catch (e) {}
    Object.entries(window.hudWidgets.active).forEach(([type, id]) => {
      const el = document.getElementById(id);
      const d = window.hudWidgets.positions[type];
      if (!el || !d) return;
      el.style.left = d.x + 'px';
      el.style.top = d.y + 'px';
      el.style.width = d.w + 'px';
      el.style.height = d.h + 'px';
    });
  };
  const resetHudBtn = document.getElementById('resetHudLayoutBtn');
  if (resetHudBtn) resetHudBtn.addEventListener('click', window.resetHudLayout);

  // Create widget
  // Padding and border add to the outer size when box-sizing is content-box, so resize must subtract them.
  function boxExtra(el) {
    const cs = getComputedStyle(el);
    if (cs.boxSizing === 'border-box') return { w: 0, h: 0 };
    return {
      w: parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight) + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth),
      h: parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom) + parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth)
    };
  }

  // Finds the largest text size at which the text fits the box. Only the text is measured: diagrams and
  // their overflow (for example the scaled ejection diagram) are ignored. A diagram keeps at least 40% of
  // the box height, so the text never takes all the room.
  function fitHudText(widget) {
    const inner = widget.querySelector('.hud-inner');
    const content = widget.querySelector('.hud-content');
    const title = widget.querySelector('.hud-title');
    if (!inner || !content || !widget.isConnected) return;
    const isFigure = (el) => el.tagName.toLowerCase() === 'svg' || !!el.querySelector('svg');
    // Figures that have a fixed size (flex-grow 0, such as the ejection diagram) count in full; figures
    // that fill the leftover space (such as the phase gauge) only need the room the text leaves.
    const isFixedFigure = (ch) => isFigure(ch) && parseFloat(getComputedStyle(ch).flexGrow) === 0;
    const hasFlexFigure = Array.from(content.children).some((ch) => isFigure(ch) && !isFixedFigure(ch));
    const fits = () => {
      const boxH = inner.clientHeight;
      const boxW = inner.clientWidth;
      let textH = title ? title.offsetHeight + parseFloat(getComputedStyle(title).marginBottom) : 0;
      let fixedH = 0, fixedW = 0;
      Array.from(content.children).forEach((ch) => {
        // SVG elements have no offsetWidth/offsetHeight, so measure figures with getBoundingClientRect.
        if (isFixedFigure(ch)) { const r = ch.getBoundingClientRect(); fixedH += r.height; fixedW = Math.max(fixedW, r.width); }
        else if (!isFigure(ch)) textH += ch.offsetHeight;
      });
      if (fixedW > boxW + 1) return false;
      const needed = textH + fixedH;
      return hasFlexFigure ? needed <= boxH * 0.6 : needed <= boxH;
    };
    let lo = 6, hi = 60;
    for (let i = 0; i < 10; i++) {
      const mid = (lo + hi) / 2;
      widget.style.setProperty('--u', mid + 'px');
      if (fits()) lo = mid; else hi = mid;
    }
    widget.style.setProperty('--u', lo + 'px');
  }

  window.createHudWidget = function(id, type, title) {
    const existing = document.getElementById(id);
    if (existing) return existing;

    const defs = getDefaultPositions();
    const pos = window.hudWidgets.positions[type] || defs[type] || { x: 100, y: 100, w: 290, h: 180 };
    
    const widget = document.createElement('div');
    widget.id = id;
    widget.className = 'hud-widget';
    widget.dataset.type = type;
    widget.style.left = pos.x + 'px';
    widget.style.top = pos.y + 'px';
    widget.style.width = pos.w + 'px';
    widget.style.height = pos.h + 'px';
    widget.innerHTML = `
      <div class="hud-inner">
        <div class="hud-title">${title}</div>
        <div class="hud-content"></div>
      </div>
      <div class="hud-buttons">
        <button class="hud-btn hud-pin-btn" title="Pin widget">📌</button>
        <button class="hud-btn hud-close-btn" title="Close widget">✕</button>
      </div>
      <div class="hud-resize-handle"></div>
    `;

    // Restore pinned state if previously saved
    try {
      const pinned = JSON.parse(localStorage.getItem('kerbalist_widget_pinned') || '[]');
      if (pinned.includes(type)) {
        widget.classList.add('pinned');
        const pinBtn = widget.querySelector('.hud-pin-btn');
        if (pinBtn) pinBtn.classList.add('active');
      }
    } catch (e) {}

    hudContainer.appendChild(widget);
    attachWidgetHandlers(widget, type);
    fitHudText(widget);
    if (window.ResizeObserver) new ResizeObserver(() => fitHudText(widget)).observe(widget);
    window.hudWidgets.active[type] = id;
    return widget;
  };

  // Close widget
  window.closeHudWidget = function(id) {
    const widget = document.getElementById(id);
    if (widget) {
      widget.remove();
      // Find type and clear from active
      for (let [type, wid] of Object.entries(window.hudWidgets.active)) {
        if (wid === id) {
          delete window.hudWidgets.active[type];
          if (window.updateButtonStateForType) {
            window.updateButtonStateForType(type);
          }
          break;
        }
      }
      savePositions();
      if (window.saveActiveWidgets) {
        window.saveActiveWidgets();
      }
    }
  };

  // Attach drag/resize/pin handlers
  function attachWidgetHandlers(widget, type) {
    let isDragging = false;
    let isResizing = false;
    let startX, startY, startLeft, startTop, startWidth, startHeight;
    const pinBtn = widget.querySelector('.hud-pin-btn');
    const closeBtn = widget.querySelector('.hud-close-btn');
    const resizeHandle = widget.querySelector('.hud-resize-handle');

    // Drag handler
    widget.addEventListener('mousedown', (e) => {
      if (e.target.closest('.hud-buttons') || e.target.closest('.hud-resize-handle')) return;
      if (widget.classList.contains('pinned')) return;

      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      startLeft = widget.offsetLeft;
      startTop = widget.offsetTop;
      widget.classList.add('dragging');
      e.preventDefault();
    });

    // Resize handler
    if (resizeHandle) {
      resizeHandle.addEventListener('mousedown', (e) => {
        if (widget.classList.contains('pinned')) return;
        isResizing = true;
        startX = e.clientX;
        startY = e.clientY;
        startWidth = widget.offsetWidth;
        startHeight = widget.offsetHeight;
        e.preventDefault();
        e.stopPropagation();
      });
    }

    // Mouse move
    document.addEventListener('mousemove', (e) => {
      if (isDragging) {
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        widget.style.left = (startLeft + dx) + 'px';
        widget.style.top = (startTop + dy) + 'px';
      } else if (isResizing) {
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        const extra = boxExtra(widget);
        widget.style.width = Math.max(140, startWidth + dx - extra.w) + 'px';
        widget.style.height = Math.max(90, startHeight + dy - extra.h) + 'px';
      }
    });

    // Mouse up
    document.addEventListener('mouseup', () => {
      if (isDragging || isResizing) {
        widget.classList.remove('dragging');
        isDragging = false;
        isResizing = false;
        // Save position
        window.hudWidgets.positions[type] = {
          x: parseInt(widget.style.left),
          y: parseInt(widget.style.top),
          w: parseInt(widget.style.width),
          h: parseInt(widget.style.height)
        };
        savePositions();
      }
    });

    // Pin button
    if (pinBtn) {
      pinBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        widget.classList.toggle('pinned');
        pinBtn.classList.toggle('active');
        savePositions();
      });
    }

    // Close button
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        window.closeHudWidget(widget.id);
      });
    }
  }

  // Update widget content
  window.updateHudContent = function(id, content) {
    const widget = document.getElementById(id);
    if (widget) {
      const contentDiv = widget.querySelector('.hud-content');
      if (contentDiv) {
        if (widget._lastHtml === content) return;   // nothing changed, so nothing to re-fit
        widget._lastHtml = content;
        contentDiv.innerHTML = content;
        fitHudText(widget);
      }
    }
  };
})();
